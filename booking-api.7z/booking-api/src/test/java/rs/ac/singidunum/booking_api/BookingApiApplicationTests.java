package rs.ac.singidunum.booking_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
